package com.troikasoft.flutter_assessment;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
